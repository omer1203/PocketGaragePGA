// User.kt
package com.example.registrationcheck

data class User(
    val firstName: String,
    val lastName: String,
    val userId: String,
    val email: String,
    val phone: String,
    val password: String,
    val securityQuestion: String,
    val securityAnswer: String
)
